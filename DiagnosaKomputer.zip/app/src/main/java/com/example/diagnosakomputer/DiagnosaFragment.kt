package com.example.diagnosakomputer

import android.app.AlertDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class DiagnosaFragment : AppCompatActivity() {

    private val gejalaList = listOf("Layar tidak tampil", "Bunyi beep terus menerus", "Komputer lambat")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_diagnosa)

        val listViewGejala: ListView = findViewById(R.id.listViewGejala)
        val btnDiagnosa: Button = findViewById(R.id.btnDiagnosa)

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice, gejalaList)
        listViewGejala.adapter = adapter
        listViewGejala.choiceMode = ListView.CHOICE_MODE_MULTIPLE

        btnDiagnosa.setOnClickListener {
            val selectedGejala = mutableListOf<String>()
            for (i in gejalaList.indices) {
                if (listViewGejala.isItemChecked(i)) {
                    selectedGejala.add(gejalaList[i])
                }
            }
            val hasil = getDiagnosa(selectedGejala)
            showHasilDialog(hasil)
        }
    }

    private fun getDiagnosa(gejala: List<String>): String {
        return when {
            "Layar tidak tampil" in gejala && "Bunyi beep terus menerus" in gejala -> "Kemungkinan RAM rusak atau tidak terpasang dengan baik."
            "Komputer lambat" in gejala -> "Kemungkinan terlalu banyak aplikasi startup atau hard disk bermasalah."
            else -> "Silakan cek komponen hardware lebih lanjut."
        }
    }

    private fun showHasilDialog(hasil: String) {
        AlertDialog.Builder(this)
            .setTitle("Hasil Diagnosa")
            .setMessage(hasil)
            .setPositiveButton("OK", null)
            .show()
    }
}